<?php
/**
 * php think build --module common
 * php think make:controller member/Member
 * php think clear
 * php think optimize:autoload
 * php think optimize:config
 */

return [
    // 生成运行时目录
    '__file__' => ['common.php'],


    // 定义common模块的自动生成
    'common'=>[
        '__dir__'   =>  ['behavior','controller','model','command'],
        'command'  =>  ['test']
    ],

    // 定义test模块的自动生成
    'member'=>[
        '__dir__'   =>  ['behavior','controller','model','validate'],
        'controller'=>  ['Member'],
        'model'     =>  ['Member','MemberIntergral']
    ],
];